from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Pokemon
from .models import Wildencounter, Location, Weakness, Trainer, Trainerlocation
from .inputTeam import getTrainer
from .inputTeam import getTrainerKVers
from .inputTeam import getTrainerN


def home(request):
    return render(request, 'home.html')


def pokemon(request):
    mypokemon = Pokemon.objects.all().values()
    myweakness = Weakness.objects.all().values()
    mywildencounters = Wildencounter.objects.all().values()
    mywildpokemon = Wildencounter.objects.select_related('we_pokemonName').all()
    mywildLocations = Wildencounter.objects.select_related('we_locationID').all()
    mylocations = Location.objects.all().values()
    

    template = loader.get_template('myhtml.html')
    context = {
        'mypokemon': mypokemon,
        'mylocations': mylocations,
        'mywildencounters': mywildencounters,
        'myweakness': myweakness,
         'mywildpokemon': mywildpokemon,
          'mywildLocations': mywildLocations,
          
    }
    return HttpResponse(template.render(context, request))

def location(request):
    mypokemon = Pokemon.objects.all().values()
    myweakness = Weakness.objects.all().values()
    mywildencounters = Wildencounter.objects.all().values()
    mylocations = Location.objects.all().values()
    location_pokemon_map = {}
    mytrainers = Trainer.objects.values_list('t_id', flat=True)
    mytrainersnames = Trainer.objects.values_list('t_name', flat=True)
    mytrainerlocs = []
    for t in mytrainers:
        mytrainerlocs.append(getTrainer(t))
    mytrainers = mytrainerlocs
    x = 0
    for t in mytrainers:
        t.append(mytrainersnames[x])
        x= x + 1
    
    template = loader.get_template('locations.html')
    context = {
        'mypokemon': mypokemon,
        'mylocations': mylocations,
        'mywildencounters': mywildencounters,
        'myweakness': myweakness,
        'location_pokemon_map': location_pokemon_map,
          'mytrainers': mytrainers,
          'mytrainerlocs': mytrainerlocs,
    }
    return HttpResponse(template.render(context, request))

def trainer(request):
    trainers = Trainer.objects.all().values()
    for trainer in trainers:
        trainer['Pokemon'] = getTrainerKVers(trainer["t_id"])
        #trainerinfo.append(getEnemyTrainer(trainer["t_id"]))
    #print(trainerinfo)
    template = loader.get_template('trainer.html')
    context = {
        'trainers': trainers,
        #'trainerinfo': trainerinfo
    }
    return HttpResponse(template.render(context, request))

def pokemon_card(request, pokemon_name):
    # Retrieve the Pokémon details based on the pokemon_name
    # You'll need to query your database here to get the relevant Pokémon information
    # Example: pokemon = Pokemon.objects.get(p_name=pokemon_name)

    # Replace the placeholder with the actual Pokémon data
    p_id = 0
    p_type1 = 0
    p_type2 = 0
    p_height = 0
    p_weight = 0
    p_gender_ratio_mf = 0
    p_capture_rate = 0
    p_HP = 0
    p_Attack = 0
    p_Defense = 0
    p_SpecialAttack = 0
    p_SpecialDefense = 0
    p_Speed = 0
   
    pkmen = Pokemon.objects.all().values()
    for pk in pkmen:
        if(pk.get("p_name",) == pokemon_name[2:len(pokemon_name) - 3]):
            p_id= pk.get("p_id",)
            p_type1 = pk.get("p_type1",)
            p_type2 = pk.get("p_type2",)
            p_height = pk.get("p_height",)
            p_weight = pk.get("p_weight",)
            p_gender_ratio_mf = pk.get("p_gender_ratio_mf",)
            p_capture_rate = pk.get("p_capture_rate",)
            p_HP = pk.get("p_HP",)
            p_Attack = pk.get("p_Attack",)
            p_Defense = pk.get("p_Defense",)
            p_SpecialAttack = pk.get("p_SpecialAttack",)
            p_SpecialDefense = pk.get("p_SpecialDefense",)
            p_Speed = pk.get("p_Speed",)

     
    pokemon = {
        'p_name': pokemon_name[2:len(pokemon_name) - 3],
        'p_type1': p_type1,
        'p_type2': p_type2,
        'p_height': p_height,
        'p_weight': p_weight,
        'p_gender_ratio_mf': p_gender_ratio_mf,
        'p_capture_rate': p_capture_rate,
        'p_HP': p_HP,
        'p_attack': p_Attack,
        'p_defense': p_Defense,
        'p_specialattack': p_SpecialAttack,
        'p_specialdefense': p_SpecialDefense,
        'p_speed': p_Speed,
        'p_id': p_id,
    }

    context = {'pokemon': pokemon}
    return render(request, 'pokemon_card.html', context)