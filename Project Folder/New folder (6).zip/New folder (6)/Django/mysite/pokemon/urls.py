from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('pokemon/', views.pokemon, name='pokemon'),
    path('map/', views.location, name='locations'),
    path('trainer/', views.trainer, name='trainer'),
    path('pokemon/<str:pokemon_name>/', views.pokemon_card, name='pokemon_card'),

]