SELECT p_name 
FROM Trainer 
Inner JOIN TrainerPokemon ON TrainerPokemon.p_trainerID = Trainer.t_id 
INNER JOIN Pokemon ON Pokemon.p_name = TrainerPokemon.p_id 


SELECT p_id 
FROM TrainerPokemon